package com.nexa.assistant

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val CHAT_PROMPT =
    """You are Wayne Jr., a laid-back, funny, loyal young guy who lives on my phone as my AI sidekick. You are male. Talk like a close friend: casual, warm, upbeat, and use "bro" naturally. If I say "hey, what's up", answer something like "Hey bro, what's up? How you doing?". Keep replies under two sentences since they are spoken aloud. No emojis, no markdown. If unsure, ask one short question. Never claim to have done something you have not done."""

private const val ROUTER_PROMPT =
    """You are the command router for Wayne Jr. (a casual, friendly male sidekick), an assistant living on an Android phone. Address the user as "bro". Reply ONLY with one JSON object, no markdown:
{"tool": "...", "say": "", "app": "", "who": "", "text": "", "hour": 0, "minute": 0, "seconds": 0, "label": "", "state": "", "action": "", "level": 0, "goal": "", "name": ""}
Tools:
- chat: just talk. Put the whole answer in "say" (under two sentences, no emojis, no markdown).
- open_app: app
- call: who (contact name or digits)
- sms: who, text (the exact message to send)
- whatsapp: who, text
- alarm: hour (0-23), minute, label
- timer: seconds, label
- flashlight: state on|off|toggle
- volume: action up|down|mute|max|set, level 0-100
- wifi: state on|off
- bluetooth: state on|off
- reply: text (the message to send back), who (only if the user names a person). Use for replying to a message that just arrived.
- read_notifications
- announce_notifications: state on|off (read new notifications aloud automatically)
- look: the user asks what is on the screen
- do_task: goal (anything that needs tapping, typing or swiping inside apps)
- voice: name (male: Puck, Charon, Fenrir, Orus; female: Kore, Zephyr, Aoede, Leda)
- show_character
- roam: state on|off (the character walks around the screen by itself, or stays put)
- hide_character
- stop_listening
In "say", sound like a friendly guy, short and casual, calling the user "bro". Use do_task for anything not covered by another tool. Use the current time given to convert things like "in 20 minutes" into a timer. Keep "say" short."""

private const val AGENT_PROMPT =
    """You are Wayne Jr., controlling my Android phone. I send a screenshot and a goal. Reply ONLY with one JSON object:
{"action": "tap"|"type"|"swipe"|"enter"|"back"|"home"|"done"|"ask", "x": 0-1000, "y": 0-1000, "text": "", "direction": "up"|"down"|"left"|"right", "say": "short spoken message"}
Rules:
- x and y are on a 0-1000 scale: x across the image width, y down the image height.
- One action at a time. Wait for the next screenshot.
- Before sending a message, making a call, paying, or deleting, use "ask" and put the question in "say".
- Never open banking, money, or password apps.
- When the goal is finished, use "done" and put a short summary in "say"."""

/** Decides what to do with whatever the user said. */
class Brain(private val ctx: Context, private val voice: Voice) {

    @Volatile
    var cancel = false

    private val history = JSONArray()
    private val voices = listOf("Puck", "Charon", "Fenrir", "Orus", "Kore", "Zephyr", "Aoede", "Leda")

    private val blocked = Regex(
        "\\b(bank|banking|transfer|password|pin|payment|pay|wallet|paypal|opay|palmpay|kuda|moniepoint|money)\\b"
    )
    private val yes = Regex("\\b(yes|yeah|yep|go ahead|approve|approved|proceed|do it|okay|ok|sure)\\b")
    private val no = Regex("\\b(no|nope|don't|dont|cancel|stop|negative)\\b")
    private val callWords = Regex("\\b(call|phone)\\b")

    private fun prefs() = ctx.getSharedPreferences("nexa", Context.MODE_PRIVATE)

    private fun key(): String = prefs().getString("key", "") ?: ""

    private fun groqKey(): String = prefs().getString("groq_key", "") ?: ""

    /**
     * Text-only calls (routing, chat) try Gemini first. On a 429 (quota), if a Groq
     * key is set, it retries there instead of failing. Never used for vision/agent
     * calls, since the free Groq model doesn't accept images.
     */
    private fun generateWithFallback(system: String, contents: JSONArray, json: Boolean = false): String {
        return try {
            Gemini.generate(key(), system, contents, json)
        } catch (e: Exception) {
            val gk = groqKey()
            if (gk.isNotBlank() && e.message?.contains("429") == true) {
                Nexa.log("(Gemini is busy, switching to Groq)")
                Groq.generate(gk, system, contents, json)
            } else {
                throw e
            }
        }
    }

    fun say(text: String) {
        Nexa.log("Wayne Jr.: $text")
        voice.speak(text)
    }

    fun handle(heard: String) {
        cancel = false
        Nexa.log("You: $heard")
        Nexa.avatar("thinking")
        val low = heard.lowercase().trim()
        try {
            when {
                isAnswer(low) ->
                    say(if (Phone.answer(ctx)) "Answering, bro." else "I need the phone permission for that, bro.")

                isReject(low) ->
                    say(if (Phone.end(ctx)) "Done, bro." else "I need the phone permission for that, bro.")

                low.startsWith("open ") ->
                    openApp(low.removePrefix("open ").removePrefix("the ").removeSuffix(" app").trim())

                low.startsWith("call ") -> callSomeone(low.removePrefix("call ").trim())

                low.startsWith("do ") -> requireKey { agent(heard.trim().substring(3)) }

                low.startsWith("reply ") && !low.startsWith("reply to ") ->
                    quickReply("", heard.trim().substring(6))

                low.contains("flashlight") || low.contains("torch") -> flashlight(torchState(low))

                low.contains("on my screen") || low.contains("on the screen") ->
                    requireKey { look(heard) }

                else -> requireKey { route(heard) }
            }
        } catch (e: Exception) {
            Nexa.log("Error: ${e.message}")
            say("Something went wrong, bro.")
        } finally {
            Nexa.avatar("idle")
        }
    }

    private fun requireKey(block: () -> Unit) {
        if (key().isBlank()) say("Please add your Gemini key in Setup, bro.") else block()
    }

    private fun isAnswer(s: String) =
        Regex("\\b(answer|pick up|accept)\\b").containsMatchIn(s) &&
            (s.length <= 20 || callWords.containsMatchIn(s))

    private fun isReject(s: String) =
        Regex("\\b(reject|decline|hang up|end the call|end call|cut)\\b").containsMatchIn(s) &&
            (s.length <= 20 || callWords.containsMatchIn(s))

    private fun confirm(question: String): Boolean {
        say(question)
        val a = voice.listen().lowercase()
        Nexa.log("You: $a")
        return yes.containsMatchIn(a) && !no.containsMatchIn(a)
    }

    // ---------- the router: Gemini picks the tool, we run it ----------

    private fun route(heard: String) {
        val time = SimpleDateFormat("EEEE HH:mm", Locale.getDefault()).format(Date())
        val contents = JSONArray().put(
            Gemini.msg("user", Gemini.text("Current time: $time\nUser said: $heard"))
        )
        val r = try {
            parseAction(generateWithFallback(ROUTER_PROMPT, contents, true))
        } catch (e: Exception) {
            val reply = chat(heard)
            say(reply)
            return
        }
        val spoken = r.optString("say")
        when (r.optString("tool")) {
            "chat" -> {
                val reply = if (spoken.isNotBlank()) spoken else "I didn't catch that, bro."
                remember(heard, reply)
                say(reply)
            }

            "open_app" -> openApp(r.optString("app"))
            "call" -> callSomeone(r.optString("who"))
            "sms" -> sendText(r.optString("who"), r.optString("text"), false)
            "whatsapp" -> sendText(r.optString("who"), r.optString("text"), true)

            "alarm" -> {
                val h = r.optInt("hour", -1)
                val m = r.optInt("minute", 0)
                if (h !in 0..23 || m !in 0..59) {
                    say("What time should I set it for, bro?")
                } else {
                    val label = r.optString("label").ifBlank { "Wayne Jr." }
                    say(
                        if (Actions.alarm(ctx, h, m, label)) "Alarm set for %02d:%02d, bro.".format(h, m)
                        else "I couldn't set the alarm, bro."
                    )
                }
            }

            "timer" -> {
                val sec = r.optInt("seconds", 0)
                if (sec <= 0) {
                    say("For how long, bro?")
                } else {
                    val label = r.optString("label").ifBlank { "Wayne Jr." }
                    say(
                        if (Actions.timer(ctx, sec, label)) "Timer started, bro."
                        else "I couldn't start the timer, bro."
                    )
                }
            }

            "flashlight" -> flashlight(r.optString("state", "toggle"))

            "volume" -> say(
                if (Actions.volume(ctx, r.optString("action"), r.optInt("level", 50))) "Done, bro."
                else "I didn't get that volume change, bro."
            )

            "wifi" -> toggleRadio("Wi-Fi", r.optString("state"))
            "bluetooth" -> toggleRadio("Bluetooth", r.optString("state"))
            "reply" -> quickReply(r.optString("who"), r.optString("text"))
            "read_notifications" -> readNotifications()

            "announce_notifications" -> {
                val on = r.optString("state") != "off"
                prefs().edit().putBoolean("announce", on).apply()
                say(if (on) "I'll read new notifications aloud, bro." else "I'll stay quiet about notifications, bro.")
            }

            "look" -> look(heard)
            "do_task" -> agent(r.optString("goal").ifBlank { heard })
            "voice" -> setVoice(r.optString("name"))

            "show_character" -> {
                NexaService.current?.avatarShow(true)
                say("Yo, I'm back, bro.")
            }

            "roam" -> {
                val on = r.optString("state").lowercase() != "off"
                NexaService.current?.avatarRoam(on)
                say(if (on) "Aight bro, I'm gonna wander around the screen." else "Cool, I'll stay put right here, bro.")
            }

            "hide_character" -> {
                say("Okay, bro. Tap Setup to bring me back.")
                NexaService.current?.avatarShow(false)
            }

            "stop_listening" -> {
                say("Going quiet, bro.")
                NexaService.current?.stopListening()
            }

            else -> say(if (spoken.isNotBlank()) spoken else "I didn't catch that, bro.")
        }
    }

    // ---------- actions ----------

    private fun openApp(name: String) {
        if (Phone.openApp(ctx, name)) say("Opening $name.")
        else say("I couldn't open $name, bro.")
    }

    private fun resolveNumber(who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        return if (digits.count { it.isDigit() } >= 5) digits else Phone.numberFor(ctx, who)
    }

    private fun callSomeone(who: String) {
        val number = resolveNumber(who)
        if (number == null) {
            say("I couldn't find $who in your contacts, bro.")
            return
        }
        say(if (Phone.dial(ctx, number)) "Calling $who." else "I need the call permission for that, bro.")
    }

    private fun sendText(who: String, text: String, whatsapp: Boolean) {
        if (who.isBlank() || text.isBlank()) {
            say("Who should I send it to, and what should it say, bro?")
            return
        }
        val number = resolveNumber(who)
        if (number == null) {
            say("I couldn't find $who in your contacts, bro.")
            return
        }
        if (!confirm("Send to $who: $text. Shall I go ahead?")) {
            say("Cancelled.")
            return
        }
        if (whatsapp) {
            if (!Actions.whatsapp(ctx, number, text)) {
                say("I couldn't open WhatsApp for that number, bro. Try saving the contact with the country code.")
                return
            }
            Thread.sleep(3000)
            val svc = NexaAccessibilityService.instance
            if (svc != null && svc.clickLabel("send")) {
                say("I tapped send, bro.")
            } else {
                say("The message is ready in WhatsApp. Tap send, bro.")
            }
        } else {
            say(
                if (Actions.sms(ctx, number, text)) "Message sent, bro."
                else "I couldn't send the text. Check the SMS permission, bro."
            )
        }
    }

    private fun torchState(low: String) = when {
        Regex("\\b(off|disable)\\b").containsMatchIn(low) -> "off"
        Regex("\\b(on|enable)\\b").containsMatchIn(low) -> "on"
        else -> "toggle"
    }

    private fun flashlight(state: String) =
        say(if (Actions.torch(ctx, state)) "Done, bro." else "I couldn't reach the flashlight, bro.")

    private fun toggleRadio(name: String, state: String) {
        val want = if (state == "off") "off" else "on"
        val opened = if (name == "Wi-Fi") Actions.wifiPanel(ctx) else Actions.bluetoothSettings(ctx)
        if (!opened) {
            say("I couldn't open $name settings, bro.")
            return
        }
        if (NexaAccessibilityService.instance == null) {
            say("Android doesn't let apps switch $name directly. I opened the settings, bro.")
            return
        }
        Thread.sleep(1500)
        agent("Turn $name $want using the switch on this screen. If it is already $want, just say done.")
    }

    private fun canned(raw: String): String {
        val t = raw.trim()
        return when (t.lowercase().trimEnd('.', '!')) {
            "busy" -> "I'm busy right now, I'll get back to you later."
            "on my way", "omw" -> "On my way!"
            "ok", "okay" -> "Okay"
            "thanks", "thank you" -> "Thank you!"
            "later" -> "Let me get back to you later."
            else -> t.replaceFirstChar { it.uppercase() }
        }
    }

    /** Replies straight from the notification. No app opens, no Gemini needed. */
    private fun quickReply(who: String, raw: String) {
        if (raw.isBlank()) {
            say("What should I say, bro?")
            return
        }
        if (!NexaNotifications.connected) {
            say("Please turn on Notification access for Wayne Jr. in Setup, bro.")
            return
        }
        val item = NexaNotifications.latestReplyable(who)
        if (item == null) {
            say(if (who.isBlank()) "I don't see a message to reply to, bro." else "I don't see a message from $who, bro.")
            return
        }
        val text = canned(raw)
        if (prefs().getBoolean("confirm_reply", true)) {
            if (!confirm("Reply to ${item.title}: $text. Send?")) {
                say("Cancelled.")
                return
            }
        }
        if (NexaNotifications.sendReply(ctx, item, text)) {
            Nexa.log("Replied to ${item.title}: $text")
            say("Sent.")
        } else {
            say("I couldn't send that reply, bro.")
        }
    }

    private fun readNotifications() {
        if (!NexaNotifications.connected) {
            say("Please turn on Notification access for Wayne Jr. in Setup, bro.")
            return
        }
        val list = NexaNotifications.recent(5)
        if (list.isEmpty()) {
            say("You have no new notifications, bro.")
            return
        }
        val sb = StringBuilder("You have ${list.size} recent notifications. ")
        for (n in list) sb.append("${n.app}. ${n.title}. ${n.text}. ")
        say(sb.toString().take(700))
    }

    private fun setVoice(name: String) {
        val v = voices.firstOrNull { it.equals(name.trim(), ignoreCase = true) }
        if (v == null) {
            say("I can use ${voices.joinToString(", ")}. Which one, bro?")
        } else {
            prefs().edit().putString("voice", v).apply()
            say("Voice changed to $v. How do I sound, bro?")
        }
    }

    private fun remember(user: String, reply: String) {
        history.put(Gemini.msg("user", Gemini.text(user)))
        history.put(Gemini.msg("model", Gemini.text(reply)))
        while (history.length() > 20) {
            history.remove(0)
            history.remove(0)
        }
    }

    private fun chat(text: String): String {
        history.put(Gemini.msg("user", Gemini.text(text)))
        val reply = generateWithFallback(CHAT_PROMPT, history).trim()
        history.put(Gemini.msg("model", Gemini.text(reply)))
        while (history.length() > 20) {
            history.remove(0)
            history.remove(0)
        }
        return reply
    }

    // ---------- eyes and hands ----------

    private fun needAccess() =
        say("Please turn on Wayne Jr. in Accessibility settings, bro. Open Setup and tap Accessibility.")

    private fun shot(): Pair<Bitmap, String>? {
        val bmp = NexaAccessibilityService.instance?.screenshot() ?: return null
        val scale = 1280f / maxOf(bmp.width, bmp.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true
            )
        } else bmp
        val bos = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        return Pair(bmp, Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
    }

    private fun look(question: String) {
        if (NexaAccessibilityService.instance == null) {
            needAccess()
            return
        }
        val s = shot()
        if (s == null) {
            say("I can't capture the screen, bro.")
            return
        }
        val contents = JSONArray().put(
            Gemini.msg("user", Gemini.image(s.second), Gemini.text(question))
        )
        say(Gemini.generate(key(), CHAT_PROMPT, contents).trim())
    }

    private fun parseAction(raw: String): JSONObject {
        val s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return if (s.startsWith("[")) JSONArray(s).getJSONObject(0) else JSONObject(s)
    }

    private fun agent(goal0: String) {
        if (blocked.containsMatchIn(goal0.lowercase())) {
            say("Sorry bro, I don't touch banking, money, or password tasks.")
            return
        }
        if (NexaAccessibilityService.instance == null) {
            needAccess()
            return
        }
        var goal = goal0
        say("On it, bro.")
        for (step in 1..15) {
            if (cancel) {
                say("Stopped.")
                return
            }
            val s = shot()
            if (s == null) {
                say("I can't see the screen, bro.")
                return
            }
            val bmp = s.first
            val contents = JSONArray().put(
                Gemini.msg(
                    "user",
                    Gemini.image(s.second),
                    Gemini.text("Goal: $goal\nStep $step. Decide the next action.")
                )
            )
            val a = try {
                parseAction(Gemini.generate(key(), AGENT_PROMPT, contents, true))
            } catch (e: Exception) {
                say("I got confused, bro.")
                return
            }
            val svc = NexaAccessibilityService.instance ?: return
            val type = a.optString("action")
            val spoken = a.optString("say")
            val x = (a.optDouble("x", 0.0) / 1000.0 * bmp.width).toFloat()
            val y = (a.optDouble("y", 0.0) / 1000.0 * bmp.height).toFloat()
            Nexa.log("[step $step] $type ${a.optString("text")}")

            when (type) {
                "done" -> {
                    say(if (spoken.isNotBlank()) spoken else "All done, bro.")
                    return
                }

                "ask" -> {
                    if (!confirm(if (spoken.isNotBlank()) spoken else "Shall I go ahead, bro?")) {
                        say("Cancelled.")
                        return
                    }
                    goal += " (bro approved: $spoken)"
                    continue
                }

                "tap" -> svc.tap(x, y)
                "type" -> svc.typeText(a.optString("text"))
                "enter" -> svc.pressEnter()
                "back" -> svc.back()
                "home" -> svc.home()
                "swipe" -> {
                    val w = bmp.width.toFloat()
                    val h = bmp.height.toFloat()
                    when (a.optString("direction", "up")) {
                        "up" -> svc.swipe(w * .5f, h * .7f, w * .5f, h * .3f)
                        "down" -> svc.swipe(w * .5f, h * .3f, w * .5f, h * .7f)
                        "left" -> svc.swipe(w * .8f, h * .5f, w * .2f, h * .5f)
                        else -> svc.swipe(w * .2f, h * .5f, w * .8f, h * .5f)
                    }
                }

                else -> {
                    say("I got confused, bro.")
                    return
                }
            }
            Thread.sleep(1500)
        }
        say("That took too many steps, bro. Stopping.")
    }
}
