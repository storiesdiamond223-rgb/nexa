package com.nexa.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import kotlin.random.Random
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.io.File
import kotlin.math.abs
import kotlin.math.sin

private val HAIR = Color.parseColor("#2A1A10")
private val SKIN = Color.parseColor("#E9B98F")
private val HOODIE = Color.parseColor("#2563EB")
private val HOODIE_DARK = Color.parseColor("#1D4ED8")
private val IRIS = Color.parseColor("#5B3A1E")
private val DARK = Color.parseColor("#1A1A1A")
private val MOUTH = Color.parseColor("#9A3412")

/** The small floating character that stays on top of every app. Tap to talk, drag to move. */
class Avatar(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var view: AvatarView? = null

    var onTap: (() -> Unit)? = null

    private var layout: WindowManager.LayoutParams? = null
    private var anim: ValueAnimator? = null
    private var touching = false

    private val roamStep = object : Runnable {
        override fun run() {
            val v = view
            val lp = layout
            if (v == null || lp == null || !prefs().getBoolean("roam", true)) return
            if (touching || Nexa.avatarState != "idle") {
                main.postDelayed(this, 2000)
                return
            }
            val dm = ctx.resources.displayMetrics
            val maxX = (dm.widthPixels - dp(90)).coerceAtLeast(0)
            val minY = dp(90)
            val maxY = (dm.heightPixels - dp(112) - dp(160)).coerceAtLeast(minY + 1)
            val tx = Random.nextInt(0, maxX + 1)
            val ty = Random.nextInt(minY, maxY + 1)
            val sx = lp.x
            val sy = lp.y
            val dist = Math.hypot((tx - sx).toDouble(), (ty - sy).toDouble())
            val ms = (dist / dp(70) * 1000).toLong().coerceIn(1200L, 9000L)
            v.facing = if (tx < sx) -1 else 1
            v.walking = true
            anim?.cancel()
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = ms
                interpolator = LinearInterpolator()
                addUpdateListener { a ->
                    val f = a.animatedValue as Float
                    lp.x = (sx + (tx - sx) * f).toInt()
                    lp.y = (sy + (ty - sy) * f).toInt()
                    try {
                        wm.updateViewLayout(v, lp)
                    } catch (ex: Exception) {
                        cancel()
                    }
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: android.animation.Animator) {
                        v.walking = false
                        prefs().edit().putInt("ax", lp.x).putInt("ay", lp.y).apply()
                        scheduleRoam()
                    }
                })
                start()
            }
        }
    }

    private fun scheduleRoam() {
        main.removeCallbacks(roamStep)
        if (view != null && prefs().getBoolean("roam", true)) {
            main.postDelayed(roamStep, Random.nextLong(4000, 10000))
        }
    }

    /** Wayne walks around the screen by himself when roaming is on. */
    fun setRoaming(on: Boolean) {
        main.post {
            if (on) scheduleRoam() else {
                main.removeCallbacks(roamStep)
                anim?.cancel()
                view?.walking = false
            }
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun prefs() = ctx.getSharedPreferences("nexa", Context.MODE_PRIVATE)

    private fun loadCustom(): Bitmap? {
        val f = File(ctx.filesDir, "avatar.png")
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun show() {
        main.post { showNow() }
    }

    fun hide() {
        main.post { hideNow() }
    }

    fun refreshImage() {
        main.post { view?.custom = loadCustom() }
    }

    private fun showNow() {
        if (view != null) return
        if (!Settings.canDrawOverlays(ctx)) return
        val v = AvatarView(ctx)
        v.custom = loadCustom()
        v.contentDescription = "Wayne Jr."
        val lp = WindowManager.LayoutParams(
            dp(90), dp(112),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs().getInt("ax", dp(12))
        lp.y = prefs().getInt("ay", dp(200))
        layout = lp

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    touching = true
                    anim?.cancel()
                    v.walking = false
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                            // view already gone
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    touching = false
                    scheduleRoam()
                    if (moved) {
                        prefs().edit().putInt("ax", lp.x).putInt("ay", lp.y).apply()
                    } else {
                        onTap?.invoke()
                    }
                }
            }
            true
        }
        try {
            wm.addView(v, lp)
            view = v
            v.state = Nexa.avatarState
            scheduleRoam()
            Nexa.avatarSink = { s -> main.post { view?.state = s } }
        } catch (e: Exception) {
            view = null
        }
    }

    private fun hideNow() {
        main.removeCallbacks(roamStep)
        anim?.cancel()
        view?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        view = null
        Nexa.avatarSink = null
    }
}

/** Draws an original chibi character with blinking, bobbing and a talking mouth. */
internal class AvatarView(ctx: Context) : View(ctx) {
    var state: String = "idle"
    var custom: Bitmap? = null
    var walking: Boolean = false
    var facing: Int = 1

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val t0 = SystemClock.uptimeMillis()
    private var u = 1f

    private fun ov(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        box.set((cx - rx) * u, (cy - ry) * u, (cx + rx) * u, (cy + ry) * u)
        c.drawOval(box, p)
    }

    override fun onDraw(c: Canvas) {
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        u = width / 100f
        val bob = sin(t * (if (walking) 9f else 2.2f)) * (if (walking) 2.6f else 1.8f) * u

        // glow behind the character
        if (state == "listening") {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.5f * u
            p.color = Color.argb(170, 34, 211, 238)
            c.drawCircle(50f * u, 62f * u, (46f + 2f * sin(t * 6f)) * u, p)
        } else if (state == "speaking") {
            p.style = Paint.Style.FILL
            p.color = Color.argb(45, 124, 58, 237)
            c.drawCircle(50f * u, 62f * u, 48f * u, p)
        }

        c.save()
        c.translate(0f, bob)
        if (facing < 0) c.scale(-1f, 1f, width / 2f, height / 2f)

        val bm = custom
        if (bm != null) {
            if (state == "speaking") {
                val s = 1f + 0.03f * sin(t * 12f)
                c.scale(s, s, width / 2f, height / 2f)
            }
            val sc = minOf(width / bm.width.toFloat(), height / bm.height.toFloat())
            val w = bm.width * sc
            val h = bm.height * sc
            box.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
            c.drawBitmap(bm, null, box, p)
        } else {
            drawCharacter(c, t)
        }
        c.restore()

        if (state == "thinking") {
            for (i in 0..2) {
                ov(c, 40f + i * 10f, 8f - sin(t * 6f + i) * 1.5f, 2.2f, 2.2f, Color.parseColor("#22D3EE"))
            }
        }
        postInvalidateDelayed(50)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * u
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
        c.drawLine(x1 * u, y1 * u, x2 * u, y2 * u, p)
        p.style = Paint.Style.FILL
    }

    /** Original chibi guy: short hair, blue hoodie, easy grin. */
    private fun drawCharacter(c: Canvas, t: Float) {
        val step = if (walking) sin(t * 9f) * 5f else 0f
        // shoes (swing while walking)
        ov(c, 41f + step, 121f, 7f, 3.5f, DARK)
        ov(c, 59f - step, 121f, 7f, 3.5f, DARK)
        // hoodie body
        ov(c, 50f, 108f, 22f, 15f, HOODIE)
        ov(c, 50f, 97f, 15f, 6f, HOODIE_DARK)
        line(c, 45f, 100f, 44f, 111f, 1.2f, Color.WHITE)
        line(c, 55f, 100f, 56f, 111f, 1.2f, Color.WHITE)
        // ears and head
        ov(c, 21f, 60f, 4.5f, 5.5f, SKIN)
        ov(c, 79f, 60f, 4.5f, 5.5f, SKIN)
        ov(c, 50f, 58f, 29f, 28f, SKIN)
        // short hair with a quiff
        p.style = Paint.Style.FILL
        p.color = HAIR
        box.set(20f * u, 26f * u, 80f * u, 70f * u)
        c.drawArc(box, 180f, 180f, true, p)
        ov(c, 24f, 47f, 4.5f, 10f, HAIR)
        ov(c, 76f, 47f, 4.5f, 10f, HAIR)
        ov(c, 40f, 42f, 10f, 6f, HAIR)
        ov(c, 56f, 40f, 11f, 7f, HAIR)
        ov(c, 62f, 29f, 13f, 7f, HAIR)
        // eyebrows
        val lift = if (state == "thinking") -2.5f else 0f
        line(c, 31f, 55f + lift, 45f, 54f, 2.4f, HAIR)
        line(c, 55f, 54f, 69f, 55f + lift, 2.4f, HAIR)
        // eyes
        val blink = (t % 4f) < 0.15f
        for (ex in floatArrayOf(39f, 61f)) {
            if (blink) {
                ov(c, ex, 65f, 5.5f, 1f, DARK)
            } else {
                ov(c, ex, 64f, 5.5f, 7.2f, Color.WHITE)
                ov(c, ex, 65f, 4.2f, 5.8f, IRIS)
                ov(c, ex, 66f, 2.2f, 3.2f, DARK)
                ov(c, ex - 1.5f, 62.2f, 1.4f, 1.4f, Color.WHITE)
            }
        }
        // nose
        ov(c, 50f, 71f, 1.8f, 1.2f, Color.argb(90, 120, 60, 30))
        // mouth
        when (state) {
            "speaking" -> ov(c, 50f, 79f, 4.5f, 1.8f + 2.8f * abs(sin(t * 14f)), MOUTH)
            "thinking" -> ov(c, 52f, 79f, 2.2f, 1.8f, MOUTH)
            else -> {
                box.set(41f * u, 71f * u, 59f * u, 84f * u)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * u
                p.color = MOUTH
                c.drawArc(box, 20f, 140f, false, p)
                p.style = Paint.Style.FILL
            }
        }
    }
}
