package com.nexa.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Announces who is calling, if Wayne Jr. is running. */
class CallReceiver : BroadcastReceiver() {

    companion object {
        private var lastAnnounced = 0L
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (intent.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
        val svc = NexaService.current ?: return

        val now = System.currentTimeMillis()
        if (now - lastAnnounced < 4000) return
        lastAnnounced = now

        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val who = Phone.contactName(context, number)
            ?: number?.map { it.toString() }?.joinToString(" ")
            ?: "an unknown number"
        svc.announce("Incoming call from $who. Say Wayne answer, or Wayne reject.")
    }
}
