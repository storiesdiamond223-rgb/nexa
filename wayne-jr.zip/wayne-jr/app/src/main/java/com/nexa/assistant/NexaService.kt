package com.nexa.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import java.util.concurrent.Executors

/** Keeps Wayne Jr. alive, listening, and showing its floating character over every app. */
class NexaService : Service() {

    companion object {
        const val ACTION_ONCE = "com.nexa.assistant.ONCE"
        const val ACTION_LOOP = "com.nexa.assistant.LOOP"
        const val ACTION_STOP = "com.nexa.assistant.STOP"
        const val ACTION_START = "com.nexa.assistant.START"
        const val ACTION_REFRESH = "com.nexa.assistant.REFRESH"

        @Volatile
        var current: NexaService? = null

        @Volatile
        var looping = false

        private val WAKE = Regex("\\b(wayne junior|wayne jr|wayne|wane|wain)\\b")
    }

    private lateinit var voice: Voice
    private lateinit var brain: Brain
    private lateinit var avatar: Avatar
    private val clap = ClapDetector()
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile
    private var forceWake = false

    private fun prefs() = getSharedPreferences("nexa", MODE_PRIVATE)

    override fun onCreate() {
        super.onCreate()
        current = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nexa", "Wayne Jr.", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "nexa")
            .setContentTitle("Wayne Jr. is active")
            .setContentText("Tap to open")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        voice = Voice(applicationContext)
        brain = Brain(applicationContext, voice)
        avatar = Avatar(applicationContext)
        avatar.onTap = { tapped() }
        if (prefs().getBoolean("avatar", true)) avatar.show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ONCE -> tapped()

            ACTION_LOOP -> if (!looping) {
                looping = true
                exec.execute { loop() }
            }

            ACTION_STOP -> {
                looping = false
                brain.cancel = true
                clap.stop()
                voice.abortListen()
                stopSelf()
            }

            ACTION_REFRESH -> avatar.refreshImage()
        }
        return START_NOT_STICKY
    }

    /** Tapping the character (or the TALK button) cancels any task and starts listening. */
    private fun tapped() {
        brain.cancel = true
        voice.interrupt()
        if (looping) {
            forceWake = true
            clap.stop()
            voice.abortListen()
        } else {
            exec.execute {
                brain.cancel = false
                Nexa.status("Listening...")
                val heard = voice.listen()
                if (heard.isNotBlank()) brain.handle(heard) else Nexa.log("(I didn't catch that)")
                Nexa.status("Ready")
            }
        }
    }

    private fun loop() {
        while (looping) {
            val clapMode = prefs().getString("wake", "voice") == "clap"
            var woke = false
            var command = ""

            if (forceWake) {
                forceWake = false
                woke = true
            } else if (clapMode) {
                Nexa.status("Listening for a double clap...")
                woke = clap.waitForDoubleClap()
                if (!looping) break
                if (forceWake) {
                    forceWake = false
                    woke = true
                } else if (!woke) {
                    Thread.sleep(1000)
                    continue
                }
            } else {
                Nexa.status("Listening for \"Hey Wayne\"...")
                val heard = voice.listen().lowercase()
                if (!looping) break
                if (forceWake) {
                    forceWake = false
                    woke = true
                } else if (heard.isBlank()) {
                    Thread.sleep(300)
                    continue
                } else {
                    val m = WAKE.find(heard) ?: continue
                    woke = true
                    command = heard.substring(m.range.last + 1).trim().trimStart(',', '.', '!', ' ')
                }
            }

            if (!woke) continue
            brain.cancel = false
            if (command.isBlank()) {
                voice.chime()
                Nexa.status("Listening...")
                command = voice.listen()
            }
            if (command.isNotBlank()) brain.handle(command)
        }
        Nexa.status("Ready")
    }

    fun announce(text: String) {
        Nexa.log("Wayne Jr.: $text")
        voice.speakAsync(text)
    }

    fun avatarRoam(on: Boolean) {
        prefs().edit().putBoolean("roam", on).apply()
        avatar.setRoaming(on)
    }

    fun avatarShow(on: Boolean) {
        prefs().edit().putBoolean("avatar", on).apply()
        if (on) avatar.show() else avatar.hide()
    }

    fun stopListening() {
        looping = false
        clap.stop()
        voice.abortListen()
    }

    /** Makes the wake loop notice a changed setting right away. */
    fun kick() {
        clap.stop()
        voice.abortListen()
    }

    override fun onDestroy() {
        looping = false
        current = null
        clap.stop()
        Nexa.status("Stopped")
        if (::avatar.isInitialized) avatar.hide()
        exec.shutdownNow()
        if (::voice.isInitialized) voice.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
