package com.nexa.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var loopBtn: Button

    private val bg = Color.parseColor("#0A0F1F")
    private val cyan = Color.parseColor("#22D3EE")
    private val panel = Color.parseColor("#151C33")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun prefs() = getSharedPreferences("nexa", Context.MODE_PRIVATE)

    private fun shape(color: Int, radius: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) this.shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }

    private fun pill(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 14f
        background = shape(panel, 24)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "WAYNE JR."
            setTextColor(cyan)
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.3f
            gravity = Gravity.CENTER
        }
        statusView = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        logView = TextView(this).apply {
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 15f
            setPadding(dp(14), dp(14), dp(14), dp(14))
            Nexa.history().forEach { append(it + "\n\n") }
            if (text.isEmpty()) {
                text = "Tap TALK, tap the floating character, or say \"Hey Wayne\".\n\nTry:\n" +
                    "- \"Hey bro, what's up?\"\n- \"Wayne, walk around the screen\"\n- \"Wayne, stay put\"\n" +
                    "- \"Open WhatsApp\"\n- \"Turn on the flashlight\"\n- \"Set an alarm for 6:30 am\"\n" +
                    "- \"Text Mum I'm on my way\"\n- \"Read my notifications\"\n- \"What's on my screen?\"\n" +
                    "- \"Do scroll down\"\n"
            }
        }
        scroll = ScrollView(this).apply {
            background = shape(panel, 16)
            addView(logView)
        }
        root.addView(title)
        root.addView(statusView)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                topMargin = dp(16)
                bottomMargin = dp(16)
            }
        )

        val mic = Button(this).apply {
            text = "TALK"
            setTextColor(bg)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            background = shape(cyan, 0, oval = true)
            setOnClickListener { talk() }
        }
        root.addView(
            mic,
            LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )

        loopBtn = pill("Always listening: OFF") { toggleLoop() }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rowParams = { w: Float ->
            LinearLayout.LayoutParams(0, dp(48), w).apply { topMargin = dp(16); marginEnd = dp(6) }
        }
        row.addView(loopBtn, rowParams(2f))
        row.addView(pill("Stop") { stopNexa() }, rowParams(1f))
        row.addView(pill("Setup") { showSetup() }, rowParams(1f))
        root.addView(row)

        setContentView(root)

        val missing = neededPermissions()
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        if (prefs().getString("key", "").isNullOrBlank()) askKey()
    }

    override fun onResume() {
        super.onResume()
        Nexa.sink = { line ->
            ui.post {
                logView.append(line + "\n\n")
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        Nexa.statusSink = { s -> ui.post { statusView.text = s } }
        refreshLoopLabel()
        startCharacterIfPossible()
    }

    override fun onPause() {
        Nexa.sink = null
        Nexa.statusSink = null
        super.onPause()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startCharacterIfPossible()
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Starts the service so the floating character appears (needs mic permission and overlay). */
    private fun startCharacterIfPossible() {
        if (prefs().getBoolean("avatar", true) && hasMic() && Settings.canDrawOverlays(this)) {
            send(NexaService.ACTION_START)
        }
    }

    private fun refreshLoopLabel() {
        loopBtn.text = if (NexaService.looping) "Always listening: ON" else "Always listening: OFF"
    }

    private fun neededPermissions(): List<String> {
        val all = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        return all.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    /** Returns true when everything needed is ready. */
    private fun ready(): Boolean {
        val missing = neededPermissions()
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return false
        }
        if (prefs().getString("key", "").isNullOrBlank()) {
            askKey()
            return false
        }
        return true
    }

    private fun send(action: String) {
        val i = Intent(this, NexaService::class.java).setAction(action)
        startForegroundService(i)
    }

    private fun talk() {
        if (ready()) send(NexaService.ACTION_ONCE)
    }

    private fun toggleLoop() {
        if (NexaService.looping) {
            send(NexaService.ACTION_STOP)
            NexaService.looping = false
        } else if (ready()) {
            send(NexaService.ACTION_LOOP)
            NexaService.looping = true
        }
        refreshLoopLabel()
    }

    private fun stopNexa() {
        send(NexaService.ACTION_STOP)
        NexaService.looping = false
        refreshLoopLabel()
    }

    private fun askKey() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API key (blank keeps current)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val k = input.text.toString().trim()
                if (k.isNotEmpty()) prefs().edit().putString("key", k).apply()
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun askGroqKey() {
        val input = EditText(this).apply {
            hint = "Paste Groq API key (blank keeps current, clear to disable)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Groq fallback key")
            .setMessage("Used only when Gemini is rate-limited, for chat and routing (not vision or voice).")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val k = input.text.toString().trim()
                if (k.isNotEmpty()) prefs().edit().putString("groq_key", k).apply()
            }
            .setNeutralButton("Remove") { _, _ ->
                prefs().edit().remove("groq_key").apply()
                Nexa.log("Groq fallback key removed.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSetup() {
        val wake = if (prefs().getString("wake", "voice") == "clap") "Double clap" else "Hey Wayne"
        val shown = prefs().getBoolean("avatar", true)
        val groqSet = !prefs().getString("groq_key", "").isNullOrBlank()
        val items = arrayOf(
            "Gemini API key",
            if (groqSet) "Groq fallback key (set, tap to change)" else "Groq fallback key (optional, for when Gemini is busy)",
            "Accessibility (see and control the screen)",
            "Overlay (floating character)",
            "Notification access (read notifications)",
            "Wake with: $wake (tap to switch)",
            "Character image: choose from gallery",
            "Character image: reset to default",
            if (shown) "Hide floating character" else "Show floating character",
            if (prefs().getBoolean("confirm_reply", true)) "Quick replies: ask first (tap to send instantly)"
            else "Quick replies: send instantly (tap to ask first)"
        )
        AlertDialog.Builder(this)
            .setTitle("Wayne Jr. setup")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askKey()
                    1 -> askGroqKey()
                    2 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    3 -> startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                    4 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    5 -> {
                        val next = if (wake == "Double clap") "voice" else "clap"
                        prefs().edit().putString("wake", next).apply()
                        NexaService.current?.kick()
                        Nexa.log("Wake method: " + if (next == "clap") "double clap" else "Hey Wayne")
                    }
                    6 -> startActivityForResult(
                        Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7
                    )
                    7 -> {
                        File(filesDir, "avatar.png").delete()
                        NexaService.current?.let { send(NexaService.ACTION_REFRESH) }
                    }
                    8 -> {
                        val on = !shown
                        prefs().edit().putBoolean("avatar", on).apply()
                        val svc = NexaService.current
                        if (svc != null) svc.avatarShow(on) else if (on) startCharacterIfPossible()
                    }
                    9 -> {
                        val ask = !prefs().getBoolean("confirm_reply", true)
                        prefs().edit().putBoolean("confirm_reply", ask).apply()
                        Nexa.log("Quick replies: " + if (ask) "ask first" else "send instantly")
                    }
                }
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            saveAvatar(uri)
        }
    }

    private fun saveAvatar(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 600 || bounds.outHeight / sample > 800) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return
            File(filesDir, "avatar.png").outputStream().use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            startCharacterIfPossible()
            NexaService.current?.let { send(NexaService.ACTION_REFRESH) }
            Nexa.log("Character image updated.")
        } catch (e: Exception) {
            Nexa.log("I couldn't load that image.")
        }
    }
}
