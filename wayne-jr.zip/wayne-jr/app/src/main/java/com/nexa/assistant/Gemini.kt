package com.nexa.assistant

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val MODEL = "gemini-3.8-flash"
    private const val THINKING = "low" // faster spoken replies; use "medium" for harder tasks

    // Natural voice models, tried in order. The first one that works is remembered.
    private val TTS_MODELS = arrayOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")

    @Volatile
    private var ttsIdx = 0

    fun text(t: String): JSONObject = JSONObject().put("text", t)

    fun image(base64Jpeg: String): JSONObject = JSONObject().put(
        "inline_data",
        JSONObject().put("mime_type", "image/jpeg").put("data", base64Jpeg)
    )

    fun msg(role: String, vararg parts: JSONObject): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray(parts.toList()))

    fun generate(
        key: String,
        system: String,
        contents: JSONArray,
        json: Boolean = false,
        retry: Boolean = false
    ): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.doOutput = true

            val gen = JSONObject()
            if (json) gen.put("responseMimeType", "application/json")
            if (!retry) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", THINKING))
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(text(system))))
                .put("contents", contents)
                .put("generationConfig", gen)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                if (code == 400 && !retry && raw.contains("thinking", ignoreCase = true)) {
                    return generate(key, system, contents, json, retry = true)
                }
                throw Exception("Gemini error $code ${raw.take(160)}")
            }

            return JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } finally {
            conn.disconnect()
        }
    }

    /** Natural speech. Returns raw 16-bit mono PCM at 24 kHz, or null if it failed. */
    fun speech(key: String, line: String, voiceName: String): ByteArray? {
        var i = ttsIdx
        while (i < TTS_MODELS.size) {
            try {
                val pcm = speechOnce(key, line, voiceName, TTS_MODELS[i])
                if (pcm != null) {
                    ttsIdx = i
                    return pcm
                }
            } catch (e: Exception) {
                // try the next model
            }
            i++
        }
        return null
    }

    private fun speechOnce(key: String, line: String, voiceName: String, model: String): ByteArray? {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true

            val voice = JSONObject().put(
                "prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)
            )
            val gen = JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", voice))
            val prompt = "Say in a casual, friendly, upbeat young guy's voice, like talking to your best friend: $line"
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(JSONObject().put("parts", JSONArray().put(text(prompt))))
                )
                .put("generationConfig", gen)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            if (code !in 200..299) return null
            val raw = conn.inputStream.bufferedReader().use { it.readText() }
            val part = JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
            val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: return null
            return Base64.decode(inline.getString("data"), Base64.DEFAULT)
        } finally {
            conn.disconnect()
        }
    }
}
