package com.nexa.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Fallback text brain when Gemini is rate-limited. OpenAI-compatible chat endpoint.
 * Text only — no vision, no speech. Used for routing and plain chat only.
 */
object Groq {
    private const val MODEL = "openai/gpt-oss-120b"
    private const val URL_STR = "https://api.groq.com/openai/v1/chat/completions"

    /** Converts Gemini-style {role, parts:[{text}]} contents into OpenAI-style chat messages. */
    private fun toMessages(system: String, contents: JSONArray): JSONArray {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until contents.length()) {
            val c = contents.getJSONObject(i)
            val role = if (c.optString("role") == "model") "assistant" else "user"
            val parts = c.optJSONArray("parts")
            val text = StringBuilder()
            if (parts != null) {
                for (j in 0 until parts.length()) {
                    text.append(parts.getJSONObject(j).optString("text"))
                }
            }
            messages.put(JSONObject().put("role", role).put("content", text.toString()))
        }
        return messages
    }

    fun generate(key: String, system: String, contents: JSONArray, json: Boolean = false): String {
        val url = URL(URL_STR)
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true

            val body = JSONObject()
                .put("model", MODEL)
                .put("messages", toMessages(system, contents))
            if (json) body.put("response_format", JSONObject().put("type", "json_object"))
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("Groq error $code ${raw.take(160)}")

            return JSONObject(raw)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        } finally {
            conn.disconnect()
        }
    }
}
