# Wayne Jr.

Voice assistant for Android. Wayne Jr. is a laid-back male sidekick who lives over every app and walks around your screen.

## What it does
- Male character (Wayne Jr.) with a casual "hey bro" personality and a male voice (default Puck; try Charon, Fenrir or Orus).
- Roams: he wanders around the screen on his own, pauses when you talk to him or drag him. Say "Wayne, stay put" or "Wayne, walk around".
- Floating character on top of all apps. Tap it to talk, drag it anywhere.
- Natural voice (Gemini speech). Falls back to the phone's voice when offline.
- Wake it: say "Hey Wayne", or clap twice (Setup > Wake with).
- Open any app, call, answer/reject calls, send texts and WhatsApp (asks your OK first).
- Alarms, timers, flashlight, volume. Wi-Fi/Bluetooth: opens the panel and flips it for you (needs Accessibility).
- Quick reply: when a message arrives (WhatsApp, SMS, Telegram...), say "reply I'm busy" and Wayne Jr. answers from the notification, no app opens. "Reply to John ..." targets a person. Setup lets you choose ask-first or send-instantly.
- Read notifications on request, or automatically ("announce notifications on").
- "What's on my screen?" and "Do <task>": Wayne Jr. looks, taps, swipes and types step by step.
- Asks for your OK before sending, calling, paying or deleting. Refuses banking and money tasks.
- "Change voice to Puck" (male: Puck, Charon, Fenrir, Orus).

- Web search: "search for ...", "Google ...", or just ask about news, scores, prices and facts (live Google Search through Gemini).
- Ideas: "give me ideas for ...", "what should I build this week" gives three quick ideas, and you can follow up ("tell me more about two").
- "Good morning" gives a briefing: time, battery, new chats, notes, and an idea for the day.
- Notes: "take a note ...", "read my notes", "clear my notes".
- "How's my battery?" and "what time is it?".

## First run
1. Install the APK, open Wayne Jr., allow the permissions.
2. Setup > Gemini API key.
3. Setup > Accessibility > Wayne Jr. > on.
4. Setup > Overlay > allow (floating character).
5. Setup > Notification access > Wayne Jr. > on.
6. Android 13+: if a switch is greyed out, Settings > Apps > Wayne Jr. > menu > Allow restricted settings.

## Custom character
Setup > Character image. Use your own artwork (transparent PNG works best).

## Limits
- Android does not let any app speak into a live call, or flip Wi-Fi directly.
- Your key is stored on the phone only. Never share the APK after adding a key.
