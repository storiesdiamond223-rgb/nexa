package com.nexa.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import java.util.concurrent.Executors

/** Keeps Nexa alive and listening, even when you leave the app. */
class NexaService : Service() {

    companion object {
        const val ACTION_ONCE = "com.nexa.assistant.ONCE"
        const val ACTION_LOOP = "com.nexa.assistant.LOOP"
        const val ACTION_STOP = "com.nexa.assistant.STOP"

        @Volatile
        var current: NexaService? = null

        @Volatile
        var looping = false

        private val WAKE = Regex("\\b(nexa|nexus|next a|nexta)\\b")
    }

    private lateinit var voice: Voice
    private lateinit var brain: Brain
    private val exec = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        current = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nexa", "Nexa", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "nexa")
            .setContentTitle("Nexa is active")
            .setContentText("Tap to open")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        voice = Voice(applicationContext)
        brain = Brain(applicationContext, voice)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ONCE -> {
                if (looping) {
                    brain.cancel = true
                } else {
                    brain.cancel = false
                    exec.execute {
                        Nexa.status("Listening...")
                        val heard = voice.listen()
                        if (heard.isNotBlank()) brain.handle(heard) else Nexa.log("(I didn't catch that)")
                        Nexa.status("Ready")
                    }
                }
            }

            ACTION_LOOP -> if (!looping) {
                looping = true
                exec.execute { loop() }
            }

            ACTION_STOP -> {
                looping = false
                brain.cancel = true
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        while (looping) {
            Nexa.status("Listening for \"Nexa\"...")
            val heard = voice.listen().lowercase()
            if (!looping) break
            if (heard.isBlank()) {
                Thread.sleep(300)
                continue
            }
            val m = WAKE.find(heard) ?: continue
            val command = heard.substring(m.range.last + 1).trim().trimStart(',', '.', '!', ' ')
            brain.cancel = false
            if (command.isBlank()) {
                brain.say("Yes, boss?")
                val next = voice.listen()
                if (next.isNotBlank()) brain.handle(next)
            } else {
                brain.handle(command)
            }
        }
    }

    fun announce(text: String) {
        Nexa.log("Nexa: $text")
        voice.speakAsync(text)
    }

    override fun onDestroy() {
        looping = false
        current = null
        Nexa.status("Stopped")
        exec.shutdownNow()
        if (::voice.isInitialized) voice.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
