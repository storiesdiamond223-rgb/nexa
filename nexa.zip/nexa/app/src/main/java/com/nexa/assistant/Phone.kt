package com.nexa.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager

object Phone {
    private fun has(ctx: Context, perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    fun answer(ctx: Context): Boolean {
        if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return false
        return try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /** Rejects a ringing call or ends the active one. */
    fun end(ctx: Context): Boolean {
        if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return false
        return try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
        } catch (e: SecurityException) {
            false
        }
    }

    fun dial(ctx: Context, number: String): Boolean {
        if (!has(ctx, Manifest.permission.CALL_PHONE)) return false
        return try {
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val wanted = name.lowercase().trim()
        if (wanted.isEmpty()) return false
        val match = pm.queryIntentActivities(query, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(wanted)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(launch)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun contactName(ctx: Context, number: String?): String? {
        if (number.isNullOrBlank() || !has(ctx, Manifest.permission.READ_CONTACTS)) return null
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
        )
        ctx.contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    fun numberFor(ctx: Context, name: String): String? {
        if (!has(ctx, Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }
}
