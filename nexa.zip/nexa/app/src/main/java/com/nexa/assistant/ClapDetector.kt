package com.nexa.assistant

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.abs

/** Listens through the mic for two sharp claps in a row. Blocking: call from a worker thread. */
class ClapDetector {

    companion object {
        /** Lower = more sensitive (0 to 32767). Raise it if it wakes up from noise. */
        private const val MIN_PEAK = 7000.0
    }

    @Volatile
    private var running = false

    /** Returns true on a double clap, false if stopped or the mic is unavailable. */
    fun waitForDoubleClap(): Boolean {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 4096)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }

        running = true
        val chunk = ShortArray(320) // 20 ms
        var floor = 800.0
        var lastClap = 0L
        var armed = true
        try {
            rec.startRecording()
            while (running) {
                val n = rec.read(chunk, 0, chunk.size)
                if (n < 0) return false
                if (n == 0) continue
                var peak = 0
                for (i in 0 until n) {
                    val a = abs(chunk[i].toInt())
                    if (a > peak) peak = a
                }
                val threshold = maxOf(MIN_PEAK, floor * 6)
                val now = System.currentTimeMillis()
                if (peak > threshold && armed) {
                    armed = false
                    if (lastClap != 0L && (now - lastClap) in 150L..900L) return true
                    lastClap = now
                } else if (peak < threshold * 0.4) {
                    armed = true
                    floor = floor * 0.98 + peak * 0.02
                }
                if (lastClap != 0L && now - lastClap > 900L) lastClap = 0L
            }
            return false
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
                // not started
            }
            rec.release()
            running = false
        }
    }

    fun stop() {
        running = false
    }
}
