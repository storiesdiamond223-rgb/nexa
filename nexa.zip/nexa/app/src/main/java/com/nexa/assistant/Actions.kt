package com.nexa.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager
import android.telephony.TelephonyManager

/** Small phone actions: flashlight, volume, alarms, timers, texts, WhatsApp, settings panels. */
object Actions {
    private var torchOn = false

    private val COUNTRY_CODES = mapOf(
        "NG" to "234", "US" to "1", "CA" to "1", "GB" to "44", "GH" to "233",
        "KE" to "254", "ZA" to "27", "IN" to "91", "AE" to "971", "DE" to "49", "FR" to "33"
    )

    private fun launch(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun torch(ctx: Context, state: String): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            val want = when (state) {
                "on" -> true
                "off" -> false
                else -> !torchOn
            }
            cm.setTorchMode(id, want)
            torchOn = want
            true
        } catch (e: Exception) {
            false
        }
    }

    fun volume(ctx: Context, action: String, level: Int): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(stream)
        return try {
            when (action) {
                "up" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "down" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "mute" -> am.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI)
                "max" -> am.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
                "set" -> am.setStreamVolume(
                    stream, level.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI
                )
                else -> return false
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun alarm(ctx: Context, hour: Int, minute: Int, label: String): Boolean {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return launch(ctx, i)
    }

    fun timer(ctx: Context, seconds: Int, label: String): Boolean {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return launch(ctx, i)
    }

    @Suppress("DEPRECATION")
    fun sms(ctx: Context, number: String, text: String): Boolean {
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        return try {
            val manager = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            manager.sendMultipartTextMessage(number, null, manager.divideMessage(text), null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** WhatsApp needs the number with country code and no plus sign. */
    private fun intlNumber(ctx: Context, raw: String): String? {
        val n = raw.filter { it.isDigit() || it == '+' }
        if (n.startsWith("+")) return n.substring(1)
        if (n.startsWith("00")) return n.substring(2)
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val cc = COUNTRY_CODES[tm.simCountryIso.uppercase()] ?: return null
        return cc + n.removePrefix("0")
    }

    /** Opens a WhatsApp chat with the message already typed. */
    fun whatsapp(ctx: Context, number: String, text: String): Boolean {
        val intl = intlNumber(ctx, number) ?: return false
        val uri = Uri.parse("https://wa.me/$intl?text=" + Uri.encode(text))
        val direct = Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")
        if (launch(ctx, direct)) return true
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    fun wifiPanel(ctx: Context): Boolean {
        val action = if (Build.VERSION.SDK_INT >= 29) {
            Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        } else {
            Settings.ACTION_WIFI_SETTINGS
        }
        return launch(ctx, Intent(action))
    }

    fun bluetoothSettings(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
}
