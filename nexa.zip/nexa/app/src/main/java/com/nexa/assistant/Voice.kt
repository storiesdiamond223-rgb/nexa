package com.nexa.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Speech in and out. speak() and listen() block, so call them from a worker thread. */
class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private val doneLatches = ConcurrentHashMap<String, CountDownLatch>()

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { doneLatches.remove(it)?.countDown() }
                    }

                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { doneLatches.remove(it)?.countDown() }
                    }
                })
                ttsReady = true
            }
        }
    }

    fun speak(text: String) {
        if (!ttsReady) return
        val id = UUID.randomUUID().toString()
        val latch = CountDownLatch(1)
        doneLatches[id] = latch
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        latch.await(40, TimeUnit.SECONDS)
        doneLatches.remove(id)
    }

    fun speakAsync(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    fun listen(): String {
        val out = arrayOf("")
        val latch = CountDownLatch(1)
        main.post {
            try {
                recognizer?.destroy()
                val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
                recognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        latch.countDown()
                    }

                    override fun onResults(results: Bundle?) {
                        out[0] = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull() ?: ""
                        latch.countDown()
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                intent.putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                sr.startListening(intent)
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        latch.await(25, TimeUnit.SECONDS)
        main.post {
            recognizer?.destroy()
            recognizer = null
        }
        return out[0]
    }

    fun shutdown() {
        main.post {
            recognizer?.destroy()
            recognizer = null
        }
        tts?.stop()
        tts?.shutdown()
    }
}
