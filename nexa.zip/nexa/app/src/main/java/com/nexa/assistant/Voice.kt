package com.nexa.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Speech in and out. speak() and listen() block, so call them from a worker thread.
 * Nexa talks with Gemini's natural voice and falls back to the phone's own voice if offline.
 */
class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null

    @Volatile
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private val doneLatches = ConcurrentHashMap<String, CountDownLatch>()

    @Volatile
    private var interrupted = false

    @Volatile
    private var listenLatch: CountDownLatch? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { doneLatches.remove(it)?.countDown() }
                    }

                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { doneLatches.remove(it)?.countDown() }
                    }
                })
                ttsReady = true
            }
        }
    }

    private fun prefs() = ctx.getSharedPreferences("nexa", Context.MODE_PRIVATE)

    fun speak(text: String) {
        interrupted = false
        Nexa.avatar("speaking")
        try {
            val key = prefs().getString("key", "") ?: ""
            if (key.isNotBlank()) {
                val voiceName = prefs().getString("voice", "Kore") ?: "Kore"
                val pcm = Gemini.speech(key, text, voiceName)
                if (pcm != null && pcm.isNotEmpty()) {
                    if (!interrupted) play(pcm)
                    return
                }
            }
            if (!interrupted) speakSystem(text)
        } finally {
            Nexa.avatar("idle")
        }
    }

    fun speakAsync(text: String) {
        Thread { speak(text) }.start()
    }

    /** Stops whatever Nexa is saying right now. */
    fun interrupt() {
        interrupted = true
        tts?.stop()
    }

    private fun play(pcm: ByteArray) {
        val rate = 24000
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        try {
            track.write(pcm, 0, pcm.size)
            track.play()
            val frames = pcm.size / 2
            val deadline = System.currentTimeMillis() + frames * 1000L / rate + 1500
            while (!interrupted && track.playbackHeadPosition < frames &&
                System.currentTimeMillis() < deadline
            ) {
                Thread.sleep(40)
            }
            try {
                track.stop()
            } catch (e: Exception) {
                // already stopped
            }
        } finally {
            track.release()
        }
    }

    private fun speakSystem(text: String) {
        if (!ttsReady) return
        val id = UUID.randomUUID().toString()
        val latch = CountDownLatch(1)
        doneLatches[id] = latch
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        latch.await(40, TimeUnit.SECONDS)
        doneLatches.remove(id)
    }

    /** A short "I'm listening" beep. */
    fun chime() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 160)
            Thread.sleep(220)
            tg.release()
        } catch (e: Exception) {
            // no beep, no problem
        }
    }

    /** Makes a listen() call in progress return right away with nothing. */
    fun abortListen() {
        listenLatch?.countDown()
    }

    fun listen(): String {
        val out = arrayOf("")
        val latch = CountDownLatch(1)
        listenLatch = latch
        Nexa.avatar("listening")
        main.post {
            try {
                recognizer?.destroy()
                val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
                recognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        latch.countDown()
                    }

                    override fun onResults(results: Bundle?) {
                        out[0] = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull() ?: ""
                        latch.countDown()
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                intent.putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                sr.startListening(intent)
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        latch.await(25, TimeUnit.SECONDS)
        main.post {
            recognizer?.destroy()
            recognizer = null
        }
        listenLatch = null
        Nexa.avatar("idle")
        return out[0]
    }

    fun shutdown() {
        interrupted = true
        main.post {
            recognizer?.destroy()
            recognizer = null
        }
        tts?.stop()
        tts?.shutdown()
    }
}
