package com.nexa.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.io.File
import kotlin.math.abs
import kotlin.math.sin

private val HAIR = Color.parseColor("#3B2A5E")
private val SKIN = Color.parseColor("#FFE3D0")
private val DRESS = Color.parseColor("#22D3EE")
private val IRIS = Color.parseColor("#7C3AED")
private val DARK = Color.parseColor("#1E1033")
private val PINK = Color.argb(110, 255, 120, 150)
private val MOUTH = Color.parseColor("#C2415B")

/** The small floating character that stays on top of every app. Tap to talk, drag to move. */
class Avatar(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var view: AvatarView? = null

    var onTap: (() -> Unit)? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun prefs() = ctx.getSharedPreferences("nexa", Context.MODE_PRIVATE)

    private fun loadCustom(): Bitmap? {
        val f = File(ctx.filesDir, "avatar.png")
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun show() {
        main.post { showNow() }
    }

    fun hide() {
        main.post { hideNow() }
    }

    fun refreshImage() {
        main.post { view?.custom = loadCustom() }
    }

    private fun showNow() {
        if (view != null) return
        if (!Settings.canDrawOverlays(ctx)) return
        val v = AvatarView(ctx)
        v.custom = loadCustom()
        v.contentDescription = "Nexa"
        val lp = WindowManager.LayoutParams(
            dp(90), dp(112),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs().getInt("ax", dp(12))
        lp.y = prefs().getInt("ay", dp(200))

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                            // view already gone
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs().edit().putInt("ax", lp.x).putInt("ay", lp.y).apply()
                    } else {
                        onTap?.invoke()
                    }
                }
            }
            true
        }
        try {
            wm.addView(v, lp)
            view = v
            v.state = Nexa.avatarState
            Nexa.avatarSink = { s -> main.post { view?.state = s } }
        } catch (e: Exception) {
            view = null
        }
    }

    private fun hideNow() {
        view?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        view = null
        Nexa.avatarSink = null
    }
}

/** Draws an original chibi character with blinking, bobbing and a talking mouth. */
internal class AvatarView(ctx: Context) : View(ctx) {
    var state: String = "idle"
    var custom: Bitmap? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val t0 = SystemClock.uptimeMillis()
    private var u = 1f

    private fun ov(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        box.set((cx - rx) * u, (cy - ry) * u, (cx + rx) * u, (cy + ry) * u)
        c.drawOval(box, p)
    }

    override fun onDraw(c: Canvas) {
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        u = width / 100f
        val bob = sin(t * 2.2f) * 1.8f * u

        // glow behind the character
        if (state == "listening") {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.5f * u
            p.color = Color.argb(170, 34, 211, 238)
            c.drawCircle(50f * u, 62f * u, (46f + 2f * sin(t * 6f)) * u, p)
        } else if (state == "speaking") {
            p.style = Paint.Style.FILL
            p.color = Color.argb(45, 124, 58, 237)
            c.drawCircle(50f * u, 62f * u, 48f * u, p)
        }

        c.save()
        c.translate(0f, bob)

        val bm = custom
        if (bm != null) {
            if (state == "speaking") {
                val s = 1f + 0.03f * sin(t * 12f)
                c.scale(s, s, width / 2f, height / 2f)
            }
            val sc = minOf(width / bm.width.toFloat(), height / bm.height.toFloat())
            val w = bm.width * sc
            val h = bm.height * sc
            box.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
            c.drawBitmap(bm, null, box, p)
        } else {
            drawCharacter(c, t)
        }
        c.restore()

        if (state == "thinking") {
            for (i in 0..2) {
                ov(c, 40f + i * 10f, 8f - sin(t * 6f + i) * 1.5f, 2.2f, 2.2f, Color.parseColor("#22D3EE"))
            }
        }
        postInvalidateDelayed(50)
    }

    private fun drawCharacter(c: Canvas, t: Float) {
        val sway = sin(t * 2f) * 2f
        // hair behind
        ov(c, 14f + sway, 80f, 9f, 22f, HAIR)
        ov(c, 86f + sway, 80f, 9f, 22f, HAIR)
        ov(c, 50f, 52f, 37f, 38f, HAIR)
        // dress
        ov(c, 50f, 108f, 17f, 14f, DRESS)
        // head
        ov(c, 50f, 58f, 30f, 28f, SKIN)
        // fringe
        p.style = Paint.Style.FILL
        p.color = HAIR
        box.set(19f * u, 24f * u, 81f * u, 72f * u)
        c.drawArc(box, 180f, 180f, true, p)
        ov(c, 30f, 48f, 9f, 7f, HAIR)
        ov(c, 43f, 50f, 8f, 8f, HAIR)
        ov(c, 57f, 50f, 8f, 8f, HAIR)
        ov(c, 70f, 48f, 9f, 7f, HAIR)
        // hair clip
        ov(c, 72f, 32f, 4.5f, 4.5f, DRESS)
        ov(c, 72f, 32f, 1.8f, 1.8f, Color.WHITE)
        // eyes
        val blink = (t % 4f) < 0.15f
        for (ex in floatArrayOf(39f, 61f)) {
            if (blink) {
                ov(c, ex, 66f, 6.5f, 1f, DARK)
            } else {
                ov(c, ex, 65f, 6.5f, 8.5f, Color.WHITE)
                ov(c, ex, 66f, 4.8f, 6.8f, IRIS)
                ov(c, ex, 67f, 2.5f, 3.8f, DARK)
                ov(c, ex - 1.8f, 62.5f, 1.7f, 1.7f, Color.WHITE)
            }
        }
        // blush
        ov(c, 29f, 73f, 5f, 2.5f, PINK)
        ov(c, 71f, 73f, 5f, 2.5f, PINK)
        // mouth
        when (state) {
            "speaking" -> ov(c, 50f, 79f, 3.2f, 1.5f + 2.5f * abs(sin(t * 14f)), MOUTH)
            "thinking" -> ov(c, 50f, 79f, 2f, 2f, MOUTH)
            else -> {
                box.set(45f * u, 74f * u, 55f * u, 82f * u)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.3f * u
                p.color = MOUTH
                c.drawArc(box, 20f, 140f, false, p)
                p.style = Paint.Style.FILL
            }
        }
    }
}
