package com.nexa.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Lets Nexa read your notifications (only after you turn on Notification access). */
class NexaNotifications : NotificationListenerService() {

    class Item(val app: String, val title: String, val text: String)

    companion object {
        private val items = ArrayList<Item>()

        @Volatile
        var connected = false

        fun recent(max: Int): List<Item> = synchronized(items) { items.takeLast(max).reversed() }
    }

    override fun onListenerConnected() {
        connected = true
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        synchronized(items) {
            items.add(Item(app, title, text))
            if (items.size > 40) items.removeAt(0)
        }
        val announce = getSharedPreferences("nexa", MODE_PRIVATE).getBoolean("announce", false)
        if (announce) NexaService.current?.announce("$app. $title. $text".take(220))
    }
}
