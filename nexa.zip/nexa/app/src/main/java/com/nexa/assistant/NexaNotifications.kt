package com.nexa.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Lets Nexa read your notifications and reply to them (after you turn on Notification access). */
class NexaNotifications : NotificationListenerService() {

    class Item(
        val key: String,
        val app: String,
        val title: String,
        val text: String,
        val reply: Notification.Action?
    )

    companion object {
        private val items = ArrayList<Item>()

        @Volatile
        var connected = false

        fun recent(max: Int): List<Item> = synchronized(items) { items.takeLast(max).reversed() }

        /** Newest message you can reply to, optionally from a named person. */
        fun latestReplyable(who: String): Item? = synchronized(items) {
            items.lastOrNull {
                it.reply != null && (who.isBlank() || it.title.contains(who, ignoreCase = true))
            }
        }

        /** Sends a reply through the notification's own reply button. No app opens. */
        fun sendReply(ctx: Context, item: Item, text: String): Boolean {
            val action = item.reply ?: return false
            val inputs = action.remoteInputs ?: return false
            return try {
                val fill = Intent()
                val results = Bundle()
                for (r in inputs) results.putCharSequence(r.resultKey, text)
                RemoteInput.addResultsToIntent(inputs, fill, results)
                action.actionIntent.send(ctx, 0, fill)
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    override fun onListenerConnected() {
        connected = true
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    private fun findReply(n: Notification): Notification.Action? {
        val all = ArrayList<Notification.Action>()
        n.actions?.let { all.addAll(it) }
        all.addAll(Notification.WearableExtender(n).actions)
        return all.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(items) { items.removeAll { it.key == sbn.key } }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        synchronized(items) {
            items.removeAll { it.key == sbn.key }
            items.add(Item(sbn.key, app, title, text, findReply(n)))
            if (items.size > 40) items.removeAt(0)
        }
        val announce = getSharedPreferences("nexa", MODE_PRIVATE).getBoolean("announce", false)
        if (announce) NexaService.current?.announce("$app. $title. $text".take(220))
    }
}
