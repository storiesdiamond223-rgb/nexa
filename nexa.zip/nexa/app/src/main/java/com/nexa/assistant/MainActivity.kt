package com.nexa.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var loopBtn: Button

    private val bg = Color.parseColor("#0A0F1F")
    private val cyan = Color.parseColor("#22D3EE")
    private val panel = Color.parseColor("#151C33")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun prefs() = getSharedPreferences("nexa", Context.MODE_PRIVATE)

    private fun shape(color: Int, radius: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) this.shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }

    private fun pill(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 14f
        background = shape(panel, 24)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "NEXA"
            setTextColor(cyan)
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.3f
            gravity = Gravity.CENTER
        }
        statusView = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        logView = TextView(this).apply {
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 15f
            setPadding(dp(14), dp(14), dp(14), dp(14))
            Nexa.history().forEach { append(it + "\n\n") }
            if (text.isEmpty()) {
                text = "Tap TALK and say something.\n\nTry:\n- \"Open WhatsApp\"\n- \"Answer the call\"\n- \"What's on my screen?\"\n- \"Do scroll down\"\n"
            }
        }
        scroll = ScrollView(this).apply {
            background = shape(panel, 16)
            addView(logView)
        }
        root.addView(title)
        root.addView(statusView)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                topMargin = dp(16)
                bottomMargin = dp(16)
            }
        )

        val mic = Button(this).apply {
            text = "TALK"
            setTextColor(bg)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            background = shape(cyan, 0, oval = true)
            setOnClickListener { talk() }
        }
        root.addView(
            mic,
            LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )

        loopBtn = pill("Always listening: OFF") { toggleLoop() }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rowParams = { w: Float ->
            LinearLayout.LayoutParams(0, dp(48), w).apply { topMargin = dp(16); marginEnd = dp(6) }
        }
        row.addView(loopBtn, rowParams(2f))
        row.addView(pill("Stop") { stopNexa() }, rowParams(1f))
        row.addView(pill("Setup") { showSetup() }, rowParams(1f))
        root.addView(row)

        setContentView(root)

        if (prefs().getString("key", "").isNullOrBlank()) showSetup()
    }

    override fun onResume() {
        super.onResume()
        Nexa.sink = { line ->
            ui.post {
                logView.append(line + "\n\n")
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        Nexa.statusSink = { s -> ui.post { statusView.text = s } }
        refreshLoopLabel()
    }

    override fun onPause() {
        Nexa.sink = null
        Nexa.statusSink = null
        super.onPause()
    }

    private fun refreshLoopLabel() {
        loopBtn.text = if (NexaService.looping) "Always listening: ON" else "Always listening: OFF"
    }

    private fun neededPermissions(): List<String> {
        val all = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        return all.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    /** Returns true when everything needed is ready. */
    private fun ready(): Boolean {
        val missing = neededPermissions()
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return false
        }
        if (prefs().getString("key", "").isNullOrBlank()) {
            showSetup()
            return false
        }
        return true
    }

    private fun send(action: String) {
        val i = Intent(this, NexaService::class.java).setAction(action)
        startForegroundService(i)
    }

    private fun talk() {
        if (ready()) send(NexaService.ACTION_ONCE)
    }

    private fun toggleLoop() {
        if (NexaService.looping) {
            send(NexaService.ACTION_STOP)
            NexaService.looping = false
        } else if (ready()) {
            send(NexaService.ACTION_LOOP)
            NexaService.looping = true
        }
        refreshLoopLabel()
    }

    private fun stopNexa() {
        send(NexaService.ACTION_STOP)
        NexaService.looping = false
        refreshLoopLabel()
    }

    private fun showSetup() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API key (blank keeps current)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val save = {
            val k = input.text.toString().trim()
            if (k.isNotEmpty()) prefs().edit().putString("key", k).apply()
        }
        AlertDialog.Builder(this)
            .setTitle("Nexa setup")
            .setMessage(
                "1) Paste your Gemini API key and Save.\n" +
                    "2) Tap Accessibility and turn Nexa on, so it can see and control the screen.\n" +
                    "3) Tap Overlay and allow it, so Nexa can open apps while you are in another app."
            )
            .setView(input)
            .setPositiveButton("Save") { _, _ -> save() }
            .setNeutralButton("Accessibility") { _, _ ->
                save()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Overlay") { _, _ ->
                save()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            .show()
    }
}
