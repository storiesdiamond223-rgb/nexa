package com.nexa.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val MODEL = "gemini-2.5-flash"

    fun text(t: String): JSONObject = JSONObject().put("text", t)

    fun image(base64Jpeg: String): JSONObject = JSONObject().put(
        "inline_data",
        JSONObject().put("mime_type", "image/jpeg").put("data", base64Jpeg)
    )

    fun msg(role: String, vararg parts: JSONObject): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray(parts.toList()))

    fun generate(key: String, system: String, contents: JSONArray, json: Boolean = false): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.doOutput = true

            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(text(system))))
                .put("contents", contents)
            if (json) {
                body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("Gemini error $code")

            return JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } finally {
            conn.disconnect()
        }
    }
}
