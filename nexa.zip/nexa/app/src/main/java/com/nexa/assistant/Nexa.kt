package com.nexa.assistant

/** Tiny shared log/status bus between the service and the screen. */
object Nexa {
    private val backlog = ArrayList<String>()

    @Volatile
    var sink: ((String) -> Unit)? = null

    @Volatile
    var statusSink: ((String) -> Unit)? = null

    /** Drives the floating character: idle, listening, thinking, speaking. */
    @Volatile
    var avatarSink: ((String) -> Unit)? = null

    @Volatile
    var avatarState: String = "idle"

    fun log(line: String) {
        synchronized(backlog) {
            backlog.add(line)
            if (backlog.size > 60) backlog.removeAt(0)
        }
        sink?.invoke(line)
    }

    fun history(): List<String> = synchronized(backlog) { ArrayList(backlog) }

    fun status(text: String) {
        statusSink?.invoke(text)
    }

    fun avatar(state: String) {
        avatarState = state
        avatarSink?.invoke(state)
    }
}
