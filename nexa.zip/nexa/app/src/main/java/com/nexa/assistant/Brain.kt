package com.nexa.assistant

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

private const val CHAT_PROMPT =
    """You are Nexa, a loyal, witty, calm AI assistant living on my Samsung phone. Address me as "boss". Keep replies under two sentences since they are spoken aloud. No emojis, no markdown. If unsure, ask one short question. Never claim to have done something you have not done."""

private const val AGENT_PROMPT =
    """You are Nexa, controlling my Android phone. I send a screenshot and a goal. Reply ONLY with one JSON object:
{"action": "tap"|"type"|"swipe"|"enter"|"back"|"home"|"done"|"ask", "x": 0-1000, "y": 0-1000, "text": "", "direction": "up"|"down"|"left"|"right", "say": "short spoken message"}
Rules:
- x and y are on a 0-1000 scale: x across the image width, y down the image height.
- One action at a time. Wait for the next screenshot.
- Before sending a message, making a call, paying, or deleting, use "ask" and put the question in "say".
- Never open banking, money, or password apps.
- When the goal is finished, use "done" and put a short summary in "say"."""

/** Decides what to do with whatever the user said. */
class Brain(private val ctx: Context, private val voice: Voice) {

    @Volatile
    var cancel = false

    private val history = JSONArray()

    private val blocked = Regex(
        "\\b(bank|banking|transfer|password|pin|payment|pay|wallet|paypal|opay|palmpay|kuda|moniepoint|money)\\b"
    )
    private val yes = Regex("\\b(yes|yeah|yep|go ahead|approve|approved|proceed|do it|okay|ok|sure)\\b")
    private val no = Regex("\\b(no|nope|don't|dont|cancel|stop|negative)\\b")
    private val callWords = Regex("\\b(call|phone)\\b")

    private fun key(): String =
        ctx.getSharedPreferences("nexa", Context.MODE_PRIVATE).getString("key", "") ?: ""

    fun say(text: String) {
        Nexa.log("Nexa: $text")
        voice.speak(text)
    }

    fun handle(heard: String) {
        cancel = false
        Nexa.log("You: $heard")
        val low = heard.lowercase().trim()
        try {
            when {
                isAnswer(low) ->
                    say(if (Phone.answer(ctx)) "Answering, boss." else "I need the phone permission for that, boss.")

                isReject(low) ->
                    say(if (Phone.end(ctx)) "Done, boss." else "I need the phone permission for that, boss.")

                low.startsWith("open ") ->
                    openApp(low.removePrefix("open ").removePrefix("the ").removeSuffix(" app").trim())

                low.startsWith("call ") -> callSomeone(low.removePrefix("call ").trim())

                low.startsWith("do ") -> requireKey { agent(heard.trim().substring(3)) }

                low.contains("screen") -> requireKey { look(heard) }

                else -> requireKey { say(chat(heard)) }
            }
        } catch (e: Exception) {
            Nexa.log("Error: ${e.message}")
            say("Something went wrong, boss.")
        }
    }

    private fun requireKey(block: () -> Unit) {
        if (key().isBlank()) say("Please add your Gemini key in Setup, boss.") else block()
    }

    private fun isAnswer(s: String) =
        Regex("\\b(answer|pick up|accept)\\b").containsMatchIn(s) &&
            (s.length <= 20 || callWords.containsMatchIn(s))

    private fun isReject(s: String) =
        Regex("\\b(reject|decline|hang up|end the call|end call|cut)\\b").containsMatchIn(s) &&
            (s.length <= 20 || callWords.containsMatchIn(s))

    private fun openApp(name: String) {
        if (Phone.openApp(ctx, name)) say("Opening $name.")
        else say("I couldn't open $name, boss.")
    }

    private fun callSomeone(who: String) {
        val digits = who.filter { it.isDigit() }
        val number = if (digits.length >= 5) digits else Phone.numberFor(ctx, who)
        if (number == null) {
            say("I couldn't find $who in your contacts, boss.")
            return
        }
        say(if (Phone.dial(ctx, number)) "Calling $who." else "I need the call permission for that, boss.")
    }

    private fun chat(text: String): String {
        history.put(Gemini.msg("user", Gemini.text(text)))
        val reply = Gemini.generate(key(), CHAT_PROMPT, history).trim()
        history.put(Gemini.msg("model", Gemini.text(reply)))
        while (history.length() > 20) {
            history.remove(0)
            history.remove(0)
        }
        return reply
    }

    private fun needAccess() =
        say("Please turn on Nexa in Accessibility settings, boss. Open Setup and tap Accessibility.")

    private fun shot(): Pair<Bitmap, String>? {
        val bmp = NexaAccessibilityService.instance?.screenshot() ?: return null
        val scale = 1280f / maxOf(bmp.width, bmp.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true
            )
        } else bmp
        val bos = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        return Pair(bmp, Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
    }

    private fun look(question: String) {
        if (NexaAccessibilityService.instance == null) {
            needAccess()
            return
        }
        val s = shot()
        if (s == null) {
            say("I can't capture the screen, boss.")
            return
        }
        val contents = JSONArray().put(
            Gemini.msg("user", Gemini.image(s.second), Gemini.text(question))
        )
        say(Gemini.generate(key(), CHAT_PROMPT, contents).trim())
    }

    private fun parseAction(raw: String): JSONObject {
        val s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return if (s.startsWith("[")) JSONArray(s).getJSONObject(0) else JSONObject(s)
    }

    private fun agent(goal0: String) {
        if (blocked.containsMatchIn(goal0.lowercase())) {
            say("Sorry boss, I don't touch banking, money, or password tasks.")
            return
        }
        if (NexaAccessibilityService.instance == null) {
            needAccess()
            return
        }
        var goal = goal0
        say("On it, boss.")
        for (step in 1..15) {
            if (cancel) {
                say("Stopped.")
                return
            }
            val s = shot()
            if (s == null) {
                say("I can't see the screen, boss.")
                return
            }
            val bmp = s.first
            val contents = JSONArray().put(
                Gemini.msg(
                    "user",
                    Gemini.image(s.second),
                    Gemini.text("Goal: $goal\nStep $step. Decide the next action.")
                )
            )
            val a = try {
                parseAction(Gemini.generate(key(), AGENT_PROMPT, contents, true))
            } catch (e: Exception) {
                say("I got confused, boss.")
                return
            }
            val svc = NexaAccessibilityService.instance ?: return
            val type = a.optString("action")
            val spoken = a.optString("say")
            val x = (a.optDouble("x", 0.0) / 1000.0 * bmp.width).toFloat()
            val y = (a.optDouble("y", 0.0) / 1000.0 * bmp.height).toFloat()
            Nexa.log("[step $step] $type ${a.optString("text")}")

            when (type) {
                "done" -> {
                    say(if (spoken.isNotBlank()) spoken else "All done, boss.")
                    return
                }

                "ask" -> {
                    say(if (spoken.isNotBlank()) spoken else "Shall I go ahead, boss?")
                    val answer = voice.listen().lowercase()
                    Nexa.log("You: $answer")
                    if (no.containsMatchIn(answer) || !yes.containsMatchIn(answer)) {
                        say("Cancelled.")
                        return
                    }
                    goal += " (boss approved: $spoken)"
                    continue
                }

                "tap" -> svc.tap(x, y)
                "type" -> svc.typeText(a.optString("text"))
                "enter" -> svc.pressEnter()
                "back" -> svc.back()
                "home" -> svc.home()
                "swipe" -> {
                    val w = bmp.width.toFloat()
                    val h = bmp.height.toFloat()
                    when (a.optString("direction", "up")) {
                        "up" -> svc.swipe(w * .5f, h * .7f, w * .5f, h * .3f)
                        "down" -> svc.swipe(w * .5f, h * .3f, w * .5f, h * .7f)
                        "left" -> svc.swipe(w * .8f, h * .5f, w * .2f, h * .5f)
                        else -> svc.swipe(w * .2f, h * .5f, w * .8f, h * .5f)
                    }
                }

                else -> {
                    say("I got confused, boss.")
                    return
                }
            }
            Thread.sleep(1500)
        }
        say("That took too many steps, boss. Stopping.")
    }
}
