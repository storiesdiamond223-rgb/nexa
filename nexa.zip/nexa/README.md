# Nexa

Voice assistant for Android with a floating character that lives over every app.

## What it does
- Floating character on top of all apps. Tap it to talk, drag it anywhere.
- Natural voice (Gemini speech). Falls back to the phone's voice when offline.
- Wake it: say "Hey Nexa", or clap twice (Setup > Wake with).
- Open any app, call, answer/reject calls, send texts and WhatsApp (asks your OK first).
- Alarms, timers, flashlight, volume. Wi-Fi/Bluetooth: opens the panel and flips it for you (needs Accessibility).
- Quick reply: when a message arrives (WhatsApp, SMS, Telegram...), say "reply I'm busy" and Nexa answers from the notification, no app opens. "Reply to John ..." targets a person. Setup lets you choose ask-first or send-instantly.
- Read notifications on request, or automatically ("announce notifications on").
- "What's on my screen?" and "Do <task>": Nexa looks, taps, swipes and types step by step.
- Asks for your OK before sending, calling, paying or deleting. Refuses banking and money tasks.
- "Change voice to Puck" (Kore, Puck, Zephyr, Aoede, Charon, Leda, Fenrir, Orus).

## First run
1. Install the APK, open Nexa, allow the permissions.
2. Setup > Gemini API key.
3. Setup > Accessibility > Nexa > on.
4. Setup > Overlay > allow (floating character).
5. Setup > Notification access > Nexa > on.
6. Android 13+: if a switch is greyed out, Settings > Apps > Nexa > menu > Allow restricted settings.

## Custom character
Setup > Character image. Use your own artwork (transparent PNG works best).

## Limits
- Android does not let any app speak into a live call, or flip Wi-Fi directly.
- Your key is stored on the phone only. Never share the APK after adding a key.
