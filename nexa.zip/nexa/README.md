# Nexa

Voice assistant for Android. Own icon, talk to it, it controls your phone.

## What it does
- TALK button: say one command.
- Always listening: say "Nexa" then a command (works from other apps too).
- "Open WhatsApp", "Call Mum", "Call 0801...", "Answer the call", "Reject the call"
- "What's on my screen?" (Nexa looks at the screen and answers)
- "Do <task>" e.g. "Do scroll down", "Do turn on Do Not Disturb" (Nexa taps, swipes and types step by step)
- Asks for your OK before sending, calling, paying or deleting. Refuses banking and money tasks.

## First run
1. Install the APK, open Nexa, allow the permissions.
2. Setup > paste your Gemini API key > Save.
3. Setup > Accessibility > Nexa > turn on.
4. Setup > Overlay > allow (lets Nexa open apps from the background).

## Limits
- Android does not let any app speak into a live call. Nexa can answer and reject.
- Your key is stored on the phone only. Never share the APK after adding a key.
